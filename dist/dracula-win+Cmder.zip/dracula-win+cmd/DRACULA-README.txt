1) run Cmder.exe
2) when Cmder starts, run "dracula" (its seen by Cmder as its in the /bin directory)